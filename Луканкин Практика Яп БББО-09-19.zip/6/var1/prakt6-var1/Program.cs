﻿using System;

namespace prakt6_var1
{
  class Program
  {
    static void Main(string[] args)
    {
      //person Sasha_VDV = new person("Sasha","Kozel", DateTime.Parse("27.12.1984",
      //                    "");
      Console.WriteLine("Hello World!");
    }
  }
}
